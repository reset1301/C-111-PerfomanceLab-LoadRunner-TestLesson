Action()
{

	lr_start_transaction("_Forum_web_01_post_message");

	lr_start_transaction("Forum_01_05_quote");
	
	 
//	 web_reg_save_param_regexp (
//		    "ParamName=viewt",
//		    "RegExp=<a href=\"viewtopic.php?p=(.+?)#",
//	//	    "Ordinal=All",
//		LAST );

	web_url("posting.php", 
		"URL=http://{adr}/posting.php?mode=quote&p={quot}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}/{topic}", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Forum_01_05_quote",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_06_submit");

	web_submit_form("posting.php_2", 
		"Snapshot=t27.inf", 
		ITEMDATA, 
		"Name=subject", "Value=Re: testTopic", ENDITEM, 
		"Name=addbbcode18", "Value=Default", ENDITEM, 
		"Name=addbbcode20", "Value=Font size", ENDITEM, 
		"Name=helpbox", "Value=Tip: Styles can be applied quickly to selected text.", ENDITEM, 
		"Name=message", "Value=[quote=\"admin\"]testers gonna test![/quote]\r\n{comm}", ENDITEM, 
		"Name=disable_bbcode", "Value=<OFF>", ENDITEM, 
		"Name=disable_smilies", "Value=<OFF>", ENDITEM, 
		"Name=notify", "Value=<OFF>", ENDITEM, 
		"Name=post", "Value=Submit", ENDITEM, 
		EXTRARES, 
		"Url=/templates/subSilver/images/cellpic3.gif", "Referer=http://{adr}/viewtopic.php?p=431", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic1.gif", "Referer=http://{adr}/viewtopic.php?p=431", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_06_submit",LR_AUTO);

	lr_end_transaction("_Forum_web_01_post_message",LR_AUTO);

	return 0;
}
