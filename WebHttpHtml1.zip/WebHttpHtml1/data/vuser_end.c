vuser_end()
{

	lr_start_transaction("Forum_01_07_Logout");

	web_url("login.php_2", 
		"URL=http://u0351361.isp.regruhosting.ru/login.php?logout=true&sid=26433523b720170804faba601744dd48", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://u0351361.isp.regruhosting.ru/viewtopic.php?p=431", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Forum_01_07_Logout",LR_AUTO);

	return 0;
}