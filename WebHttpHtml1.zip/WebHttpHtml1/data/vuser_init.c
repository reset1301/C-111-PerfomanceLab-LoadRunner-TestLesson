/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1203
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_start_transaction("Forum_01_01_load_mainpage");

	web_url("suggest-ff.cgi", 
		"URL=https://suggest.yandex.ru/suggest-ff.cgi?srv=ie11&part=u0351361.isp.regruhosting.ru&clid=2233627", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		LAST);

	web_add_cookie("WT_FPC=id=27ff749534792501a3c1375594989679:lv=1375594989679:ss=1375594989679; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("WT_NVR_RU=0=technet:1=:2=; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20151211; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MSFPC=ID=7af73f4ddad12147a6d3bd49902b49fa&CS=1&LV=201611&V=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MC1=GUID=7af73f4ddad12147a6d3bd49902b49fa&HASH=7af7&LV=201611&V=4&LU=1479811388417; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("A=I&I=AxUFAAAAAAA4BgAAX0dBwNtNKGdXoV+4MmY8iQ!!&V=4; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("optimizelyEndUserId=oeu1497974785957r0.6582016915457552; DOMAIN=iecvlist.microsoft.com");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("u0351361.isp.regruhosting.ru", 
		"URL=http://u0351361.isp.regruhosting.ru/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/templates/subSilver/images/cellpic3.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic1.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic2.jpg", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_01_load_mainpage",LR_AUTO);

	lr_think_time(36);

	lr_start_transaction("Forum_01_02_Login");

	web_link("Log in", 
		"Text=Log in", 
		"Snapshot=t22.inf", 
		LAST);

	web_submit_form("login.php", 
		"Snapshot=t23.inf", 
		ITEMDATA, 
		"Name=username", "Value=Roman-reset", ENDITEM, 
		"Name=password", "Value=12qwertyu", ENDITEM, 
		"Name=autologin", "Value=<OFF>", ENDITEM, 
		"Name=login", "Value=Log in", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_02_Login",LR_AUTO);

	lr_think_time(49);

	lr_start_transaction("Forum_01_03_open_category");

	web_link("loadtest study 18.06", 
		"Text=loadtest study 18.06", 
		"Snapshot=t24.inf", 
		LAST);

	lr_end_transaction("Forum_01_03_open_category",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("Forum_01_03_open_topic");

	web_link("testTopic", 
		"Text=testTopic", 
		"Snapshot=t25.inf", 
		LAST);

	lr_end_transaction("Forum_01_03_open_topic",LR_AUTO);

	return 0;
}
