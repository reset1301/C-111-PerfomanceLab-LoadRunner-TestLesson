vuser_end()
{

	lr_think_time(10);

	lr_start_transaction("Forum_01_07_Logout");

	web_url("login.php_2", 
		"URL=http://{adr}/login.php?logout=true&sid={ssid}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}/viewtopic.php?p=431", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Forum_01_07_Logout",LR_AUTO);

	return 0;
}