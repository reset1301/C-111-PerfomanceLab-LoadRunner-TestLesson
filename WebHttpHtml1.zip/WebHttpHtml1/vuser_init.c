/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1203
   ------------------------------------------------------------------------------- */

vuser_init()
{

	lr_start_transaction("Forum_01_01_load_mainpage");
	
	web_reg_save_param_regexp (
	    "ParamName=ssid",
	    "RegExp=phpbb2mysql_sid=(.+);",
	LAST );

	web_url("{adr}", 
		"URL=http://{adr}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/templates/subSilver/images/cellpic3.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic1.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic2.jpg", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_01_load_mainpage",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_02_Login");

	web_link("Log in", 
		"Text=Log in", 
		"Snapshot=t22.inf", 
		LAST);

	web_submit_form("login.php", 
		"Snapshot=t23.inf", 
		ITEMDATA, 
		"Name=username", "Value={usID}", ENDITEM, 
		"Name=password", "Value={passID}", ENDITEM, 
		"Name=autologin", "Value=<OFF>", ENDITEM, 
		"Name=login", "Value=Log in", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_02_Login",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_03_open_category");
	
	web_reg_save_param_regexp (
	    "ParamName=topic",
	    "RegExp=<a href=\"(.+)\" class=\"topictitle\">{ntopic}</a>",
	LAST );


	web_link("{ncat}", 
		"Text={ncat}", 
		"Snapshot=t24.inf", 
		LAST);

	lr_end_transaction("Forum_01_03_open_category",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_03_open_topic");

	web_reg_save_param_regexp (
		    "ParamName=quot",
		    "RegExp=<a href=\"posting.php\\?mode=quote&amp;p=(.+?)\">",
	//	    "Ordinal=All",
		LAST );
	
	web_link("{ntopic}", 
		"Text={ntopic}", 
		"Snapshot=t25.inf", 
		LAST);

	lr_end_transaction("Forum_01_03_open_topic",LR_AUTO);

	lr_think_time(10);

	return 0;
}
