/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1203
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_start_transaction("Forum_01_01_load_mainpage");
	
	web_reg_save_param_regexp (
	    "ParamName=ssid",
	    "RegExp=phpbb2mysql_sid=(.+);",
	LAST );

	web_url("{adr}", 
		"URL=http://{adr}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/templates/subSilver/images/cellpic3.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic1.gif", ENDITEM, 
		"Url=/templates/subSilver/images/cellpic2.jpg", ENDITEM, 
		LAST);

	web_custom_request("ocsp.digicert.com_4", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x18\\xF8\\x85\\xA9\\x97\\x1C\\xDC{\\xEF\\x86\tm\\x01\\x98<\\xA8\\xF9\\x9F%V\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x055\\x95\\xDD\\xC4\\x88\\xE3\\xBD!\\x851l\\x9E\\x02JW", 
		LAST);

	web_custom_request("downloads_2", 
		"URL=https://shavar.services.mozilla.com/downloads?client=navclient-auto-ffox&appver=43.0.1&pver=2.2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=mozstd-track-digest256;a:1471874828\nmozstd-trackwhite-digest256;a:1478554625\n", 
		LAST);

	lr_end_transaction("Forum_01_01_load_mainpage",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_02_login");

	web_url("login.php", 
		"URL=http://{adr}/login.php?sid={ssid}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
		web_reg_save_param_regexp (
	    "ParamName=cat_link",
	    "RegExp=href=\"(.+)\" class=\"forumlink\">loadtest study 18.06</a>",
		LAST );	


	web_submit_form("login.php_2", 
		"Snapshot=t10.inf", 
		ITEMDATA, 
		"Name=username", "Value=Roman-reset", ENDITEM, 
		"Name=password", "Value=12qwertyu", ENDITEM, 
		"Name=autologin", "Value=<OFF>", ENDITEM, 
		"Name=login", "Value=Log in", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_02_login",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Forum_01_03_open_category");
	
	
	web_reg_save_param_regexp (
	    "ParamName=topic",
	    "RegExp=<a href=\"(.+)\" class=\"topictitle\">reset1301@mail.ru</a>",
	LAST );



	web_link("loadtest", 
		"Text=loadtest", 
		"Snapshot=t11.inf", 
		LAST);
	
	/*web_url("loadtest", 
		"URL=http://{host}/{cat_link}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{host}/index.php?sid={sid}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);*/

	lr_end_transaction("Forum_01_03_open_category",LR_AUTO);

	lr_think_time(10);

	return 0;
}
