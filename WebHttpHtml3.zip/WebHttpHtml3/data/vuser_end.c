vuser_end()
{

	lr_think_time(36);

	web_custom_request("ocsp.digicert.com_5", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x18\\xF8\\x85\\xA9\\x97\\x1C\\xDC{\\xEF\\x86\tm\\x01\\x98<\\xA8\\xF9\\x9F%V\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x07\\xD5\r\\xC7\\xF3h\\x98/\\xAB^\\x19\\xB9\\xC5\\xFB\\xA1\\\\", 
		LAST);

	web_add_cookie("optimizelySegments=%7B%22245617832%22%3A%22none%22%2C%22245875585%22%3A%22direct%22%2C%22245677587%22%3A%22ff%22%2C%22246048108%22%3A%22false%22%2C%22237061344%22%3A%22none%22%2C%22237335298%22%3A%22direct%22%2C%22715491832%22%3A%22true%22%2C%22237485170%22%3A%22false%22%2C%22237321400%22%3A%22ff%22%2C%22246002457%22%3A%22campaign%22%2C%22246073290%22%3A%22ff%22%2C%22245984388%22%3A%22false%22%2C%22246073289%22%3A%22none%22%7D; DOMAIN=aus5.mozilla.org");

	web_add_cookie("optimizelyEndUserId=oeu1399049547282r0.01748916441484838; DOMAIN=aus5.mozilla.org");

	web_add_cookie("optimizelyBuckets=%7B%7D; DOMAIN=aus5.mozilla.org");

	web_add_cookie("_ga=GA1.2.1120945598.1497903809; DOMAIN=aus5.mozilla.org");

	web_url("update.xml", 
		"URL=https://aus5.mozilla.org/update/3/Firefox/43.0.1/20151216175450/WINNT_x86-msvc-x64/ru/release/Windows_NT%2010.0.0.0%20(x64)/default/default/update.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://download.cdn.mozilla.net/pub/firefox/releases/47.0.2/update/win32/ru/firefox-43.0.1-47.0.2.partial.mar", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("Forum_01_06_logout");

	web_url("login.php_3", 
		"URL=http://u0351361.isp.regruhosting.ru/login.php?logout=true&sid=78cf4181c35c3ba9c9fc782c083a15bc", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://u0351361.isp.regruhosting.ru/viewtopic.php?p=373", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Forum_01_06_logout",LR_AUTO);

	return 0;
}