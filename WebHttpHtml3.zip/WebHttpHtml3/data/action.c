Action()
{

	lr_think_time(94);

	lr_start_transaction("_Forum_web_01_03_post_message");

	lr_start_transaction("Forum_01_04_quote");

	web_url("viewtopic.php", 
		"URL=http://u0351361.isp.regruhosting.ru/viewtopic.php?t=20", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://u0351361.isp.regruhosting.ru/viewforum.php?f=2", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(12);

	web_image("Reply with quote", 
		"Alt=Reply with quote", 
		"Ordinal=1", 
		"Snapshot=t13.inf", 
		LAST);

	lr_end_transaction("Forum_01_04_quote",LR_AUTO);

	lr_think_time(50);

	lr_start_transaction("Forum_01_05_submit");

	web_submit_form("posting.php", 
		"Snapshot=t14.inf", 
		ITEMDATA, 
		"Name=subject", "Value=Re: reset1301@mail.ru", ENDITEM, 
		"Name=addbbcode18", "Value=Default", ENDITEM, 
		"Name=addbbcode20", "Value=Font size", ENDITEM, 
		"Name=helpbox", "Value=Tip: Styles can be applied quickly to selected text.", ENDITEM, 
		"Name=message", "Value=[quote=\"Roman-reset\"]My new topic.[/quote]\r\n2", ENDITEM, 
		"Name=disable_bbcode", "Value=<OFF>", ENDITEM, 
		"Name=disable_smilies", "Value=<OFF>", ENDITEM, 
		"Name=notify", "Value=<OFF>", ENDITEM, 
		"Name=post", "Value=Submit", ENDITEM, 
		LAST);

	lr_end_transaction("Forum_01_05_submit",LR_AUTO);

	lr_end_transaction("_Forum_web_01_03_post_message",LR_AUTO);

	return 0;
}
