vuser_end()
{

	lr_think_time(10);

	lr_start_transaction("Forum_01_06_logout");

	web_url("login.php_3", 
		"URL=http://{adr}/login.php?logout=true&sid={ssid}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}/viewtopic.php?p=373", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Forum_01_06_logout",LR_AUTO);

	return 0;
}